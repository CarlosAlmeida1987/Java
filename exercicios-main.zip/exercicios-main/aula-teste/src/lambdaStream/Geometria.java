package lambdaStream;

public class Geometria {

	public static void main(String[] args) {
		

	}

}

interface figura{
	public double perimetro();
} 
