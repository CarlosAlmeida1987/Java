package exercicios;

public class Teste2 {

	public static void main(String[] args) {
		System.out.println(10<<2);
		System.out.println(10>>>2);
		boolean a = true;
		System.out.printf("%b",a);

	}

}
