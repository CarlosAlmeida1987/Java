package exercicios;

public class PrimeiraAula {

	public static void main(String[] args) {
		final String CONSTANTE = "NUMERO";
		final double PI = 3.14;

		int numero = 37;
		double gauss = 22.4;
		char letra = 'a';
		String palavra = "UTD";
		
		System.out.printf("%d\n",numero);
		System.out.printf("%.2f\n",gauss);
		System.out.printf("%c\n",letra);
		System.out.printf("%s\n",palavra);
		
		System.out.println(CONSTANTE);
		System.out.println(PI);
		System.err.println();
		System.out.println("xxxxxxx");
		System.out.println("x     x");
		System.out.println("x     x");
		System.out.println("x     x");
		System.out.println("xxxxxxx");
		System.out.println();
		System.out.println("      x      ");
		System.out.println("     xxx     ");
		System.out.println("    xxxxx    ");
		System.out.println("   xxxxxxx   ");
		System.out.println("  xxxxxxxxx  ");
		System.out.println(" xxxxxxxxxxx ");
		System.out.println("xxxxxxxxxxxxx");
		System.out.println("      x      ");
		System.out.println("     xxx     ");		
		
	}

}
