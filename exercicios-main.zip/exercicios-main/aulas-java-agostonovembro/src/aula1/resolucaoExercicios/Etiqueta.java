package aula1.resolucaoExercicios;

public class Etiqueta {

	public static void main(String[] args) {
		
		System.out.println("Osvaldo Souza A. Neto");
		
		System.out.println("Endere�o: Avenida Sargento Herm�nio Sampaio, 3100, Presidente Kennedy , Fortaleza - CE, 60355, Brazil");
		
		System.out.println("Telefone: +55 85 3089 9999");

	}

}
