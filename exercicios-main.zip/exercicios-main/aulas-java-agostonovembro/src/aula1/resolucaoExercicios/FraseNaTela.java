package aula1.resolucaoExercicios;

public class FraseNaTela {

	public static void main(String[] args) {
		System.out.println("Seja bem vindo ao curso de l�gica de programa��o Java");
	}
}
