package aula1.resolucaoExercicios;

public class BoasPraticas {

	public static void main(String[] args) {
		/*
		 * 
		 * 1 � Tenha um sono regular.
		   2 � Pratique exerc�cios.
           3 � Separe algumas horas do seu dia para o estudo.
           4 � Aplique o m�todo POMODORO.
           5 � Desenvolva projetos.
		 * 
		 * */

		System.out.println("1 � Tenha um sono regular.");
		System.out.println("2 � Pratique exerc�cios.");
		System.out.println("3 � Separe algumas horas do seu dia para o estudo.");
		System.out.println("4 � Aplique o m�todo POMODORO.");
		System.out.println("5 � Desenvolva projetos.");
	}

}
