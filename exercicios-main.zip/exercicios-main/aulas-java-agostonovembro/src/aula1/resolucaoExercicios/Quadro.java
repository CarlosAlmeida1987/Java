package aula1.resolucaoExercicios;

public class Quadro {

	public static void main(String[] args) {
		System.out.println("xxxxxxx");
		System.out.println("x     x");
		System.out.println("x     x");
		System.out.println("x     x");
		System.out.println("xxxxxxx");
	}

}
