package aula1.resolucaoExercicios;

public class Pinheiro {

	public static void main(String[] args) {
		System.out.println("      x      ");
		System.out.println("     xxx     ");
		System.out.println("    xxxxx    ");
		System.out.println("   xxxxxxx   ");
		System.out.println("  xxxxxxxxx  ");
		System.out.println(" xxxxxxxxxxx ");
		System.out.println("xxxxxxxxxxxxx");
		System.out.println("      x      ");
		System.out.println("     xxx     ");

	}

}
