package aula1.resolucaoExercicios;

public class Poema {

	public static void main(String[] args) {
		
		System.out.printf("Batatinha quando nasce\nEspalha a rama pelo ch�o\nMenininho quando chora\nP�e a m�o no cora��o.");
		
	}
	
}
