package aula3.exercicios;

public class Questao1 {

	public static void main(String[] args) {
		
		//boolean prop1, prop2;
		
		System.out.println("Tabela verdade E");
		System.out.println("FALSE E FALSE:"+(false && false));
		System.out.println("TRUE  E FALSE:"+(true && false));
		System.out.println("FALSE E TRUE :"+(false && true));
		System.out.println("TRUE  E TRUE :"+(true && true));
		System.out.println("-------------------------");
		System.out.println("Tabela verdade OU");
		System.out.println("FALSE OU FALSE:"+(false || false));
		System.out.println("TRUE  OU FALSE:"+(true || false));
		System.out.println("FALSE OU TRUE :"+(false || true));
		System.out.println("TRUE  OU TRUE :"+(true || true));
		
	}

}
