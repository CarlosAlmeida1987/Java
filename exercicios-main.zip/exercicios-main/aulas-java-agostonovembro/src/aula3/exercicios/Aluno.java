package aula3.exercicios;

public class Aluno {

	int id;
	String nome;
	String curso;
	
}
