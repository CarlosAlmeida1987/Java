package aula3.exercicios;

public class Questao2 {

	public static void main(String[] args) {
		int a=3, b=7, c=4;
		
		System.out.println((a+c)>b);
		System.out.println(b>=(a+2));
		System.out.println(c == (b-a));
		System.out.println((b+a)<=c);
		System.out.println((c+a)>b);
		
		System.out.println("Quest�o2");
		
		int A=5, B=4, C=3, D=6;
		
		System.out.println((A>C)&&(C<=D));
		System.out.println((A+B)>10 || (A+B)==(C+D));

	}

}
