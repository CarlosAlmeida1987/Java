package aula4.exercicios;

import java.util.Iterator;

//some todos os termos da sequ�ncia 1+1/2+1/3+...+1/100;

public class Questao5 {

	public static void main(String[] args) {
		
		double soma=0;
		
		for (int i = 1; i <=100; i++) {
			soma+=(double)1/i;
		}
		System.out.println(soma);
	}
}
