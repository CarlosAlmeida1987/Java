package aula4.exercicios;

import java.util.Scanner;

public class Questao1 {

	public static void main(String[] args) {
		
		Scanner leitor = new Scanner(System.in);
		
		System.out.println("digite o primeiro n�mero.");
		int a = leitor.nextInt();
		
		System.out.println("digite o segundo n�mero.");
		int b = leitor.nextInt();
		
		System.out.println("digite o terceiro n�mero.");
		int c = leitor.nextInt();
		
		int ab = ((a+b)+ Math.abs(a-b))/2;
		
		int maior = ((ab+c)+Math.abs(ab-c))/2;
		
		if(a>b) {
			
			if(a>c) {
				System.out.println(a);
			}else {
				System.out.println(c);
			}
			
		}else if(b>c){
			System.out.println(b);
		}else {
			System.out.println(c);
		}
		
		System.out.println(maior);
	}

}
