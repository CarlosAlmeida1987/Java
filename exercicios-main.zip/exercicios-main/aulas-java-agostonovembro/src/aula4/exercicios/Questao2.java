package aula4.exercicios;

import java.util.Scanner;

public class Questao2 {
	
	public static void main(String[] args) {
		
		Scanner leitor = new Scanner(System.in);
		
		System.out.println("Digite a temperatura em Celsius.");
		double celsius = leitor.nextDouble();
		
		double kelvin = celsius + 273;
		
		double farenheight = 1.8*celsius+32;
		
		
		System.out.printf("Celsius: %.2f",celsius);
		System.out.println();
		System.out.printf("Kelvin: %.2f",kelvin);
		System.out.println("");
		System.out.printf("Farenheight: %.2f",farenheight);
		
		
		
	}
}
