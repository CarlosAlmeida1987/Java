package aula4.explicacao;

import java.util.Iterator;

public class EstruturasDeRepeticaoIII {

	public static void main(String[] args) {
		
		int vetor[] = {1,2,3,4,5,6,7,8,9,10};
		
		for (int i = 0; i<vetor.length;i++) {
			
			System.out.println(vetor[i]);
		}
		
		for(int numero : vetor) {
			System.out.println(numero);
		}
	}
}
