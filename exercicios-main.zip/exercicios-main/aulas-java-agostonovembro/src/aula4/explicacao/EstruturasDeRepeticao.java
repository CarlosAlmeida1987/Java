package aula4.explicacao;

public class EstruturasDeRepeticao {

	public static void main(String[] args) {
		
		boolean flag = true;
		
		int contador=0;
		
		do {
			
			System.out.println("A condi��o � falsa: "+contador);			
			
			contador++;
			
			if(contador>5)
				break;
		}while(flag);
		

	}

}
