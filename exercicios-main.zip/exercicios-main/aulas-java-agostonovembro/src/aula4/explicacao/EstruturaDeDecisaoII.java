package aula4.explicacao;

import java.util.Scanner;

public class EstruturaDeDecisaoII {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("O que voc� deseja comer?");
		int opcao = scan.nextInt();
		
		switch(opcao) {
			case 1: System.out.println("Voc� escolheu sushi.");
			break;
			
			case 2: System.out.println("Voc� escolheu lasanha");
			break;
			
			case 3: System.out.println("Voc� escolheu camar�o");
			break;
			
			case 4: System.out.println("Voc� escolheu pizza");
			break;
			
			default: System.out.println("Voc� escolheu todas as anteriores");
		}
			

	}

}
