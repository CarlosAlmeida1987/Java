package aula4.explicacao;

import java.util.Scanner;

public class EstruturasDeRepeticaoII {

	public static void main(String[] args) {
		
		int contador = 1, opcao=0;
		boolean flag = true;
		Scanner leitor = new Scanner(System.in);
		
		while(flag) {
			
			System.out.println("Escolha a op��o.");
			opcao=leitor.nextInt();
			
			switch(opcao) {
			
				case 1 :System.out.println("la�o");break;
				case 2 :System.out.println("la�o");break;
				case 3 :System.out.println("la�o");break;
				case 4 :flag=false;break;
				default:System.out.println("op��o inv�lida");
			}
		}
	}
}
